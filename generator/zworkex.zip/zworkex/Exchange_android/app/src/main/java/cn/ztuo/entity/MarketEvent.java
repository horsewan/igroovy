package cn.ztuo.entity;

/**
 * Created by Administrator on 2018/4/20 0020.
 */

public class MarketEvent {
    private String resonpce;

    public String getResonpce() {
        return resonpce;
    }

    public void setResonpce(String resonpce) {
        this.resonpce = resonpce;
    }
}
