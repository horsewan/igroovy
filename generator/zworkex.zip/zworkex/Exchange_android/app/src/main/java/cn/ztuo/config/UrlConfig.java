package cn.ztuo.config;

public class UrlConfig {

    public static String BASE_URL="http://39.104.119.155/";
    public static String C2C_URL="54.255.151.74";
    public static String MARKET_URL="18.136.195.191";
    public static String GROUP_URL="54.255.151.74";
    public static String HEART_URL="54.255.151.74";

}
