package cn.ztuo.entity;

public class TypeBean  {
    public String id;
    public String type_1;
}
