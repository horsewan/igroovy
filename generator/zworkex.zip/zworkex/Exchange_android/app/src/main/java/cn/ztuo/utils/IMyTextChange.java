package cn.ztuo.utils;

import android.text.Editable;
import android.text.TextWatcher;

/**
 * author: wuzongjie
 * time  : 2018/4/19 0019 14:42
 * desc  :
 */

public class IMyTextChange implements TextWatcher{
    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {

    }
}
