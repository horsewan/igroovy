package cn.ztuo.entity;

/**
 * Created by Administrator on 2018/5/8 0008.
 */

public class PromotionRecord {

    /**
     * createTime : 2018-03-27 19:36:45
     * username : charlzon
     * level : 0
     */

    private String createTime;
    private String username;
    private int level;

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
}
