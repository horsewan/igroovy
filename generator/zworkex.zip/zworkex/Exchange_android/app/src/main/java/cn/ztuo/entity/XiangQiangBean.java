package cn.ztuo.entity;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/7/3.
 */
public class XiangQiangBean implements Serializable {
    //交易时间
    public String starTime;
    //交易对
    public String jiaoyidui;
    //方向
    public String fangxiang;
    //价格
    public String jiage;
    //委托量
    public String weituoliang;
    //已成交
    public String yichengjiao;
    //手续费
    public String shouxufei;

}
