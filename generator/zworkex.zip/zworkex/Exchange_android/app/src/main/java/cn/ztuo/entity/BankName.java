package cn.ztuo.entity;

/**
 * Created by Administrator on 2018/5/3 0003.
 */

public class BankName {
    private String bankName;
    private boolean isSelected;

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
