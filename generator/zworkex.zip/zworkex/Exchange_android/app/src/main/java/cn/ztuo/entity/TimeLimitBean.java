package cn.ztuo.entity;

/**
 * Created by Administrator on 2018/5/31 0031.
 */

public class TimeLimitBean {
    private String time;
    private boolean isSelected;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
